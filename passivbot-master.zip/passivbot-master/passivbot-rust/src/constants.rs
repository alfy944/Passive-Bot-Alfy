pub const HIGH: usize = 0;
pub const LOW: usize = 1;
pub const CLOSE: usize = 2;
pub const VOLUME: usize = 3;

pub const LONG: usize = 0;
pub const SHORT: usize = 1;
pub const NO_POS: usize = 2;
