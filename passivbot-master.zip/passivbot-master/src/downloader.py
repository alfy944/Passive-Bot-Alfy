import argparse
import asyncio
import datetime
import gzip
import json
import logging
import inspect
import math
import os
import shutil
import sys
import traceback
import zipfile
import re
from collections import deque
from functools import wraps
from io import BytesIO
from pathlib import Path
from time import time
from typing import List, Dict, Any, Tuple
from uuid import uuid4
from urllib.request import urlopen
from collections import defaultdict

import aiohttp
import pprint
import ccxt.async_support as ccxt
import numpy as np
import pandas as pd
from dateutil import parser
from tqdm import tqdm
from config_utils import (
    add_arguments_recursively,
    load_config,
    get_template_config,
    update_config_with_args,
    require_config_value,
    require_live_value,
)
from pure_funcs import (
    safe_filename,
)
from utils import (
    make_get_filepath,
    utc_ms,
    format_end_date,
    ts_to_date,
    date_to_ts,
    get_file_mod_ms,
    normalize_exchange_name,
    get_quote,
    symbol_to_coin,
    coin_to_symbol,
    load_markets,
    format_approved_ignored_coins,
)
from procedures import (
    get_first_timestamps_unified,
)

# ========================= CONFIGURABLES & GLOBALS =========================

logging.basicConfig(
    format="%(asctime)s %(levelname)-8s %(message)s",
    level=logging.INFO,
    datefmt="%Y-%m-%dT%H:%M:%S",
)

MAX_REQUESTS_PER_MINUTE = 120
REQUEST_TIMESTAMPS = deque(maxlen=1000)  # for rate-limiting checks

# ========================= HELPER FUNCTIONS =========================


def is_valid_date(date):
    try:
        ts = date_to_ts(date)
        return True
    except:
        return False


def get_function_name():
    return inspect.currentframe().f_back.f_code.co_name


def _to_float(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _require_max_warmup_minutes(config: dict) -> float:
    """Return the warmup ceiling from the live config."""
    return _to_float(require_live_value(config, "max_warmup_minutes"))


def _iter_param_sets(config: dict):
    bot_cfg = config.get("bot", {})
    base_long = dict(bot_cfg.get("long", {}) or {})
    base_short = dict(bot_cfg.get("short", {}) or {})
    yield "__default__", base_long, base_short

    coin_overrides = config.get("coin_overrides", {})
    for coin, overrides in coin_overrides.items():
        bot_overrides = overrides.get("bot", {})
        long_params = dict(base_long)
        short_params = dict(base_short)
        long_params.update(bot_overrides.get("long", {}))
        short_params.update(bot_overrides.get("short", {}))
        yield coin, long_params, short_params


def compute_backtest_warmup_minutes(config: dict) -> int:
    """Mirror Rust warmup span calculation (see calc_warmup_bars)."""

    def _extract_bound_max(bounds: dict, key: str) -> float:
        if key not in bounds:
            return 0.0
        entry = bounds[key]
        candidates = []
        if isinstance(entry, (list, tuple)):
            candidates = [entry]
        else:
            candidates = [[entry]]
        max_val = 0.0
        for candidate in candidates:
            for val in candidate:
                max_val = max(max_val, _to_float(val))
        return max_val

    max_minutes = 0.0
    minute_fields = [
        "ema_span_0",
        "ema_span_1",
        "filter_volume_ema_span",
        "filter_volatility_ema_span",
    ]

    for _, long_params, short_params in _iter_param_sets(config):
        for params in (long_params, short_params):
            for field in minute_fields:
                max_minutes = max(max_minutes, _to_float(params.get(field)))
            log_span_minutes = _to_float(params.get("entry_volatility_ema_span_hours")) * 60.0
            max_minutes = max(max_minutes, log_span_minutes)

    bounds = config.get("optimize", {}).get("bounds", {})
    bound_keys_minutes = [
        "long_ema_span_0",
        "long_ema_span_1",
        "long_filter_volume_ema_span",
        "long_filter_volatility_ema_span",
        "short_ema_span_0",
        "short_ema_span_1",
        "short_filter_volume_ema_span",
        "short_filter_volatility_ema_span",
    ]
    bound_keys_hours = [
        "long_entry_volatility_ema_span_hours",
        "short_entry_volatility_ema_span_hours",
    ]

    for key in bound_keys_minutes:
        max_minutes = max(max_minutes, _extract_bound_max(bounds, key))
    for key in bound_keys_hours:
        max_minutes = max(max_minutes, _extract_bound_max(bounds, key) * 60.0)

    warmup_ratio = float(require_config_value(config, "live.warmup_ratio"))
    limit = _require_max_warmup_minutes(config)

    if not math.isfinite(max_minutes):
        return 0
    warmup_minutes = max_minutes * max(0.0, warmup_ratio)
    if limit > 0:
        warmup_minutes = min(warmup_minutes, limit)
    return int(math.ceil(warmup_minutes)) if warmup_minutes > 0.0 else 0


def compute_per_coin_warmup_minutes(config: dict) -> dict:
    warmup_ratio = float(require_config_value(config, "live.warmup_ratio"))
    limit = _require_max_warmup_minutes(config)
    per_coin = {}
    minute_fields = [
        "ema_span_0",
        "ema_span_1",
        "filter_volume_ema_span",
        "filter_volatility_ema_span",
    ]
    for coin, long_params, short_params in _iter_param_sets(config):
        max_minutes = 0.0
        for params in (long_params, short_params):
            for field in minute_fields:
                max_minutes = max(max_minutes, _to_float(params.get(field)))
            max_minutes = max(
                max_minutes,
                _to_float(params.get("entry_volatility_ema_span_hours")) * 60.0,
            )
        if not math.isfinite(max_minutes):
            per_coin[coin] = 0
            continue
        warmup_minutes = max_minutes * max(0.0, warmup_ratio)
        if limit > 0:
            warmup_minutes = min(warmup_minutes, limit)
        per_coin[coin] = int(math.ceil(warmup_minutes)) if warmup_minutes > 0.0 else 0
    return per_coin


def dump_ohlcv_data(data, filepath):
    columns = ["timestamp", "open", "high", "low", "close", "volume"]
    if isinstance(data, pd.DataFrame):
        data = ensure_millis_df(data[columns]).astype(float).values
    elif isinstance(data, np.ndarray):
        pass
    else:
        raise Exception(f"Unknown data format for {filepath}")
    np.save(filepath, deduplicate_rows(data))


def canonicalize_daily_ohlcvs(data, start_ts: int, interval_ms: int = 60_000) -> pd.DataFrame:
    """
    Return a 1-minute canonical OHLCV DataFrame for the given day.

    Missing minutes are forward/back filled for price columns and zero-filled for volume.
    Duplicate timestamps keep the last observation.
    """
    columns = ["timestamp", "open", "high", "low", "close", "volume"]
    if isinstance(data, np.ndarray):
        df = pd.DataFrame(data, columns=columns)
    elif isinstance(data, pd.DataFrame):
        df = data[columns].copy()
    else:
        raise TypeError("data must be a pandas DataFrame or numpy array")

    df = df.reset_index(drop=True)
    df = ensure_millis_df(df)
    for col in columns:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    end_ts = start_ts + 24 * 60 * 60 * 1000
    df = df.dropna(subset=["timestamp"])
    df = df[(df["timestamp"] >= start_ts) & (df["timestamp"] < end_ts)]
    df = df.drop_duplicates(subset=["timestamp"], keep="last").sort_values("timestamp")

    if df.empty:
        raise ValueError("No data available for canonicalization")

    expected_ts = np.arange(start_ts, end_ts, interval_ms)
    reindexed = df.set_index("timestamp").reindex(expected_ts)
    missing_mask = reindexed[["open", "high", "low", "close", "volume"]].isna().all(axis=1)

    close = reindexed["close"].astype(float)
    close = close.ffill().bfill()
    if close.isna().any():
        raise ValueError("Unable to fill close prices while canonicalizing daily OHLCV data")
    reindexed["close"] = close

    for col in ["open", "high", "low"]:
        series = reindexed[col].astype(float)
        series = series.ffill().bfill()
        series = series.fillna(reindexed["close"])
        series = pd.Series(
            np.where(missing_mask, reindexed["close"], series),
            index=reindexed.index,
            dtype=float,
        )
        reindexed[col] = series

    volume = reindexed["volume"].astype(float)
    volume = volume.fillna(0.0)
    reindexed["volume"] = volume

    result = reindexed.reset_index().rename(columns={"index": "timestamp"})
    return result[columns]


def dump_daily_ohlcv_data(data, filepath, start_ts: int, interval_ms: int = 60_000):
    canonical = canonicalize_daily_ohlcvs(data, start_ts, interval_ms=interval_ms)
    dump_ohlcv_data(canonical, filepath)


def deduplicate_rows(arr):
    """
    Remove duplicate rows from a 2D NumPy array while preserving order.

    Parameters:
    arr (numpy.ndarray): Input 2D array of shape (x, y)

    Returns:
    numpy.ndarray: Array with duplicate rows removed, maintaining original order
    """
    # Convert rows to tuples for hashing
    rows_as_tuples = map(tuple, arr)

    # Keep track of seen rows while preserving order
    seen = set()
    unique_indices = [
        i
        for i, row_tuple in enumerate(rows_as_tuples)
        if not (row_tuple in seen or seen.add(row_tuple))
    ]

    # Return array with only unique rows
    return arr[unique_indices]


def load_ohlcv_data(filepath: str) -> pd.DataFrame:
    arr = np.load(filepath, allow_pickle=True)
    columns = ["timestamp", "open", "high", "low", "close", "volume"]
    arr_deduplicated = deduplicate_rows(arr)
    if len(arr) != len(arr_deduplicated):
        dump_ohlcv_data(arr_deduplicated, filepath)
        print(
            f"Caught .npy file with duplicate rows: {filepath} Overwrote with deduplicated version."
        )
    return ensure_millis_df(pd.DataFrame(arr_deduplicated, columns=columns))


def get_days_in_between(start_day, end_day):
    date_format = "%Y-%m-%d"
    start_date = datetime.datetime.strptime(format_end_date(start_day), date_format)
    end_date = datetime.datetime.strptime(format_end_date(end_day), date_format)
    days = []
    current_date = start_date
    while current_date <= end_date:
        days.append(current_date.strftime(date_format))
        current_date += datetime.timedelta(days=1)
    return days


def fill_gaps_in_ohlcvs(df):
    interval = 60000
    new_timestamps = np.arange(df["timestamp"].iloc[0], df["timestamp"].iloc[-1] + interval, interval)
    new_df = df.set_index("timestamp").reindex(new_timestamps)
    new_df.close = new_df.close.ffill()
    for col in ["open", "high", "low"]:
        new_df[col] = new_df[col].fillna(new_df.close)
    new_df["volume"] = new_df["volume"].fillna(0.0)
    return new_df.reset_index().rename(columns={"index": "timestamp"})


def attempt_gap_fix_ohlcvs(df, symbol=None, verbose=True):
    interval = 60_000
    max_hours = 12
    max_gap = interval * 60 * max_hours
    greatest_gap = df.timestamp.diff().max()
    if pd.isna(greatest_gap) or greatest_gap == interval:
        return df
    if greatest_gap > max_gap:
        raise Exception(f"Huge gap in data for {symbol}: {greatest_gap/(1000*60*60)} hours.")
    if verbose:
        logging.info(
            f"Filling small gaps in {symbol}. Largest gap: {greatest_gap/(1000*60*60):.3f} hours."
        )
    new_timestamps = np.arange(df["timestamp"].iloc[0], df["timestamp"].iloc[-1] + interval, interval)
    new_df = df.set_index("timestamp").reindex(new_timestamps)
    new_df.close = new_df.close.ffill()
    for col in ["open", "high", "low"]:
        new_df[col] = new_df[col].fillna(new_df.close)
    new_df["volume"] = new_df["volume"].fillna(0.0)
    return new_df.reset_index().rename(columns={"index": "timestamp"})


async def fetch_url(session, url, retries=5, backoff=1.5):
    last_exc = None
    for attempt in range(retries):
        try:
            async with session.get(url) as response:
                response.raise_for_status()
                return await response.read()
        except Exception as e:
            if isinstance(e, aiohttp.ClientResponseError) and getattr(e, "status", None) == 404:
                logging.warning(f"{url} returned 404; skipping retries.")
                return None
            last_exc = e
            wait_time = backoff**attempt
            logging.warning(
                f"Attempt {attempt + 1} failed for {url}: {e}, retrying in {wait_time:.1f}s..."
            )
            await asyncio.sleep(wait_time)
    logging.error(f"All {retries} attempts failed for {url}")
    raise last_exc


async def fetch_zips(url):
    async with aiohttp.ClientSession() as session:
        try:
            content = await fetch_url(session, url)
            if content is None:
                return []
            zips = []
            with zipfile.ZipFile(BytesIO(content), "r") as z:
                for f in z.namelist():
                    zips.append(z.open(f))
            return zips
        except Exception as e:
            logging.error(f"Error fetching zips {url}: {e}")
            return []


async def get_zip_binance(url):
    col_names = ["timestamp", "open", "high", "low", "close", "volume"]
    zips = await fetch_zips(url)
    if not zips:
        return pd.DataFrame(columns=col_names)
    dfs = []
    for z in zips:
        df = pd.read_csv(z, header=None)
        df.columns = col_names + [f"extra_{i}" for i in range(len(df.columns) - len(col_names))]
        dfs.append(df[col_names])
    dfc = pd.concat(dfs).sort_values("timestamp").reset_index(drop=True)
    return dfc[dfc.timestamp != "open_time"].astype(float)


async def get_zip_bitget(url):
    col_names = ["timestamp", "open", "high", "low", "close", "volume"]
    zips = await fetch_zips(url)
    if not zips:
        return pd.DataFrame(columns=col_names)
    dfs = []
    for z in zips:
        df = ensure_millis_df(pd.read_excel(z))
        df.columns = col_names + [f"extra_{i}" for i in range(len(df.columns) - len(col_names))]
        dfs.append(df[col_names])
    dfc = pd.concat(dfs).sort_values("timestamp").reset_index(drop=True)
    return dfc[dfc.timestamp != "open_time"]


def ensure_millis_df(df):
    """
    Normalize a DataFrame's 'timestamp' column to milliseconds.

    Heuristic:
    - If no valid (non-zero, finite) timestamps exist, assume timestamps are already ms.
    - If there are multiple unique timestamps, use the median difference between unique timestamps:
      if the median difference is a multiple of 1000 (within a small tolerance), treat timestamps as ms.
      Otherwise treat them as seconds and multiply by 1000.
    - If only one non-zero timestamp exists, fall back to magnitude-based detection using epoch-scale
      thresholds:
        - >= 1e15 -> microseconds
        - >= 1e12 -> milliseconds
        - >= 1e9  -> seconds
        - <  1e9  -> assume milliseconds (likely small ms values)
    This avoids mis-detecting when the first timestamp is 0 (which previously caused incorrect scaling).
    """
    if "timestamp" not in df.columns:
        return df

    # Work with a float copy for robust numeric checks
    try:
        ts = df["timestamp"].astype("float64").values
    except Exception:
        # If casting fails, leave unchanged
        return df

    # Identify finite, non-zero timestamps to base heuristics on
    finite_mask = np.isfinite(ts) & (ts != 0)
    if not finite_mask.any():
        # All timestamps are zero or invalid — assume already in milliseconds
        return df

    non_zero_ts = ts[finite_mask]
    uniq = np.unique(non_zero_ts)

    if uniq.size > 1:
        # Use median diff between unique timestamps to determine units.
        diffs = np.diff(uniq)
        median_diff = float(np.median(diffs))

        # If median_diff is a clean multiple of 1000, it's likely millisecond data (1 minute = 60000, etc).
        if abs(median_diff - round(median_diff / 1000.0) * 1000.0) < 1e-6:
            return df  # already milliseconds
        else:
            # Likely seconds -> convert to milliseconds
            df["timestamp"] = df["timestamp"] * 1000.0
            return df

    # Fallback: single representative timestamp -> magnitude-based detection
    rep = float(np.abs(non_zero_ts).max())

    # Epoch magnitude thresholds (approx):
    # - seconds:      ~1e9
    # - milliseconds: ~1e12
    # - microseconds: ~1e15
    if rep >= 1e15:
        # microseconds -> convert to milliseconds
        df["timestamp"] = df["timestamp"] / 1000.0
    elif rep >= 1e12:
        # already milliseconds
        pass
    elif rep >= 1e9:
        # seconds -> convert to milliseconds
        df["timestamp"] = df["timestamp"] * 1000.0
    else:
        # small magnitudes (< 1e9) are assumed to already be milliseconds (e.g., 60000)
        pass

    return df


class OHLCVManager:
    """
    Manages OHLCVs for multiple exchanges.
    """

    def __init__(
        self,
        exchange,
        start_date=None,
        end_date=None,
        cc=None,
        gap_tolerance_ohlcvs_minutes=120.0,
        verbose=True,
    ):
        self.exchange = normalize_exchange_name(exchange)
        self.quote = get_quote(exchange)
        self.start_date = "2020-01-01" if start_date is None else format_end_date(start_date)
        self.end_date = format_end_date("now" if end_date is None else end_date)
        self.start_ts = date_to_ts(self.start_date)
        self.end_ts = date_to_ts(self.end_date)
        self.cc = cc
        self.cache_filepaths = {
            "markets": os.path.join("caches", self.exchange, "markets.json"),
            "ohlcvs": os.path.join("historical_data", f"ohlcvs_{self.exchange}"),
            "first_timestamps": os.path.join("caches", self.exchange, "first_timestamps.json"),
        }
        self.markets = None
        self.verbose = verbose
        self.max_requests_per_minute = {"": 120, "gateio": 60}
        self.request_timestamps = deque(maxlen=1000)  # for rate-limiting checks
        self.gap_tolerance_ohlcvs_minutes = gap_tolerance_ohlcvs_minutes

    def update_date_range(self, new_start_date=None, new_end_date=None):
        if new_start_date:
            if isinstance(new_start_date, (float, int)):
                self.start_date = ts_to_date(new_start_date)
            elif isinstance(new_start_date, str):
                self.start_date = new_start_date
            else:
                raise Exception(f"invalid start date {new_start_date}")
            self.start_ts = date_to_ts(self.start_date)
        if new_end_date:
            if isinstance(new_end_date, (float, int)):
                self.end_date = ts_to_date(new_end_date)
            elif isinstance(new_end_date, str):
                self.end_date = new_end_date
            else:
                raise Exception(f"invalid end date {new_end_date}")
            self.end_date = format_end_date(self.end_date)
            self.end_ts = date_to_ts(self.end_date)

    def get_symbol(self, coin):
        assert self.markets, "needs to call self.load_markets() first"
        return coin_to_symbol(coin, self.exchange)

    def get_market_specific_settings(self, coin):
        mss = self.markets[self.get_symbol(coin)]
        mss["hedge_mode"] = True
        mss["maker_fee"] = mss["maker"]
        mss["taker_fee"] = mss["taker"]
        mss["c_mult"] = mss["contractSize"]
        mss["min_cost"] = mc if (mc := mss["limits"]["cost"]["min"]) is not None else 0.01
        mss["price_step"] = mss["precision"]["price"]
        mss["min_qty"] = max(
            lm if (lm := mss["limits"]["amount"]["min"]) is not None else 0.0,
            pm if (pm := mss["precision"]["amount"]) is not None else 0.0,
        )
        mss["qty_step"] = mss["precision"]["amount"]
        if self.exchange == "binanceusdm":
            pass
        elif self.exchange == "bybit":
            # ccxt reports incorrect fees for bybit perps
            mss["maker"] = mss["maker_fee"] = 0.0002
            mss["taker"] = mss["taker_fee"] = 0.00055
        elif self.exchange == "bitget":
            pass
        elif self.exchange in ("kucoin", "kucoinfutures"):
            # ccxt reports incorrect fees for kucoin futures. Assume VIP0
            mss["maker"] = mss["maker_fee"] = 0.0002
            mss["taker"] = mss["taker_fee"] = 0.0006
        elif self.exchange == "gateio":
            # ccxt reports incorrect fees for gateio perps. Assume VIP0
            mss["maker"] = mss["maker_fee"] = 0.0002
            mss["taker"] = mss["taker_fee"] = 0.0005
        return mss

    def filter_date_range(self, df: pd.DataFrame) -> pd.DataFrame:
        """Filter dataframe to include only data within start_date and end_date (inclusive)"""
        if df.empty:
            return df
        return df[(df.timestamp >= self.start_ts) & (df.timestamp <= self.end_ts)].reset_index(
            drop=True
        )

    def has_coin(self, coin):
        symbol = self.get_symbol(coin)
        if not symbol:
            return False
        return True

    async def check_rate_limit(self):
        current_time = time()
        while self.request_timestamps and current_time - self.request_timestamps[0] > 60:
            self.request_timestamps.popleft()
        mrpm = (
            self.max_requests_per_minute[self.exchange]
            if self.exchange in self.max_requests_per_minute
            else self.max_requests_per_minute[""]
        )
        if len(self.request_timestamps) >= mrpm:
            sleep_time = 60 - (current_time - self.request_timestamps[0])
            if sleep_time > 0:
                if self.verbose:
                    logging.info(
                        f"{self.exchange} Rate limit reached, sleeping for {sleep_time:.2f} seconds"
                    )
                await asyncio.sleep(sleep_time)

        self.request_timestamps.append(current_time)

    async def get_ohlcvs(self, coin, start_date=None, end_date=None):
        """
        - Attempts to get ohlcvs for coin from cache.
        - If any data is missing, checks if it exists to download
        - If so, download.
        - Return ohlcvs.
        - If exchange unsupported,
        coin unsupported on exchange,
        or date range for coin not existing on exchange,
        return empty dataframe
        """
        if not self.markets:
            await self.load_markets()
        if not self.has_coin(coin):
            return pd.DataFrame(columns=["timestamp", "open", "high", "low", "close", "volume"])
        if start_date or end_date:
            self.update_date_range(new_start_date=start_date, new_end_date=end_date)
        missing_days = await self.get_missing_days_ohlcvs(coin)
        if missing_days:
            await self.download_ohlcvs(coin)
        ohlcvs = await self.load_ohlcvs_from_cache(coin)
        ohlcvs.volume = ohlcvs.volume * ohlcvs.close  # use quote volume
        return ohlcvs

    async def get_start_date_modified(self, coin):
        fts = await self.get_first_timestamp(coin)
        return ts_to_date(max(self.start_ts, fts))[:10]

    async def get_missing_days_ohlcvs(self, coin):
        start_date = await self.get_start_date_modified(coin)
        days = get_days_in_between(start_date, self.end_date)
        dirpath = os.path.join(self.cache_filepaths["ohlcvs"], coin)
        if not os.path.exists(dirpath):
            return days
        all_files = os.listdir(dirpath)
        return sorted([x for x in days if x + ".npy" not in all_files])

    async def download_ohlcvs(self, coin):
        if not self.markets:
            await self.load_markets()
        if not self.has_coin(coin):
            return
        if self.exchange == "binanceusdm":
            await self.download_ohlcvs_binance(coin)
        elif self.exchange == "bybit":
            await self.download_ohlcvs_bybit(coin)
        elif self.exchange == "bitget":
            await self.download_ohlcvs_bitget(coin)
        elif self.exchange in ("kucoin", "kucoinfutures"):
            await self.download_ohlcvs_kucoin(coin)
        elif self.exchange == "gateio":
            if self.cc is None:
                self.load_cc()
            await self.download_ohlcvs_gateio(coin)

    def dump_ohlcvs_to_cache(self, coin):
        """
        Dumps new ohlcv data to cache if not already existing. Only whole days are dumped.
        """
        pass

    async def get_first_timestamp(self, coin):
        """
        Get first timestamp of available ohlcv data for given exchange & coin
        """
        if (fts := self.load_first_timestamp(coin)) not in [None, 0.0]:
            return fts
        if not self.markets:
            self.load_cc()
            await self.load_markets()
        if not self.has_coin(coin):
            self.dump_first_timestamp(coin, 0.0)
            return 0.0
        if self.exchange == "binanceusdm":
            # Fetches first by default
            ohlcvs = await self.cc.fetch_ohlcv(self.get_symbol(coin), since=1, timeframe="1d")
        elif self.exchange == "bybit":
            fts = await self.find_first_day_bybit(coin)
            return fts
        elif self.exchange == "gateio":
            # Data since 2018
            ohlcvs = await self.cc.fetch_ohlcv(
                self.get_symbol(coin), since=int(date_to_ts("2018-01-01")), timeframe="1d"
            )
            if not ohlcvs:
                ohlcvs = await self.cc.fetch_ohlcv(
                    self.get_symbol(coin), since=int(date_to_ts("2020-01-01")), timeframe="1d"
                )
        elif self.exchange in ("kucoin", "kucoinfutures"):
            fts = await self.find_first_day_kucoin(coin)
            return fts
        elif self.exchange == "bitget":
            fts = await self.find_first_day_bitget(coin)
            return fts
        if ohlcvs:
            fts = ohlcvs[0][0]
        else:
            fts = 0.0
        self.dump_first_timestamp(coin, fts)
        return fts

    def load_cc(self):
        if self.cc is None:
            self.cc = getattr(ccxt, self.exchange)({"enableRateLimit": True})
            self.cc.options["defaultType"] = "swap"

    async def load_markets(self):
        self.load_cc()
        self.markets = await load_markets(self.exchange, verbose=False)
        # Populate the ccxt client's markets without incurring another network call if possible
        try:
            if hasattr(self.cc, "set_markets"):
                self.cc.set_markets(self.markets)
        except Exception:
            pass

    def load_markets_from_cache(self, max_age_ms=1000 * 60 * 60 * 24):
        try:
            if os.path.exists(self.cache_filepaths["markets"]):
                if utc_ms() - get_file_mod_ms(self.cache_filepaths["markets"]) < max_age_ms:
                    markets = json.load(open(self.cache_filepaths["markets"]))
                    if self.verbose:
                        logging.info(f"{self.exchange} Loaded markets from cache")
                    return markets
            return {}
        except Exception as e:
            logging.error(f"Error with {get_function_name()} {e}")
            return {}

    def dump_markets_to_cache(self):
        if self.markets:
            try:
                json.dump(self.markets, open(make_get_filepath(self.cache_filepaths["markets"]), "w"))
                if self.verbose:
                    logging.info(f"{self.exchange} Dumped markets to cache")
            except Exception as e:
                logging.error(f"Error with {get_function_name()} {e}")

    async def load_ohlcvs_from_cache(self, coin):
        """
        Loads any cached ohlcv data for exchange, coin and date range from cache
        and *strictly* enforces no gaps. If any gap is found, return empty.
        """
        dirpath = os.path.join(self.cache_filepaths["ohlcvs"], coin, "")
        if not os.path.exists(dirpath):
            return pd.DataFrame()

        all_files = sorted([f for f in os.listdir(dirpath) if f.endswith(".npy")])
        all_days = get_days_in_between(self.start_date, self.end_date)
        all_months = sorted(set([x[:7] for x in all_days]))

        # Load month files first
        files_to_load = [x for x in all_files if x.replace(".npy", "") in all_months]
        # Add day files (exclude if they were loaded already as a month)
        files_to_load += [
            x for x in all_files if x.replace(".npy", "") in all_days and x not in files_to_load
        ]

        dfs = []
        for f in files_to_load:
            try:
                filepath = os.path.join(dirpath, f)
                df_part = load_ohlcv_data(filepath)
                dfs.append(df_part)
            except Exception as e:
                logging.error(f"Error loading file {f}: {e}")

        if not dfs:
            return pd.DataFrame()

        # Concatenate, drop duplicates, sort by timestamp
        df = (
            pd.concat(dfs)
            .drop_duplicates("timestamp")
            .sort_values("timestamp")
            .reset_index(drop=True)
        )
        # ----------------------------------------------------------------------
        # 1) Clip to [start_ts, end_ts] and return
        # ----------------------------------------------------------------------
        df = self.filter_date_range(df)

        # ----------------------------------------------------------------------
        # 2) Gap check with tolerance: if intervals != 60000 for any bar, return empty.
        # ----------------------------------------------------------------------
        intervals = np.diff(df["timestamp"].values)
        # If any interval is not exactly 60000, we have a gap.
        if (intervals != 60000).any():
            greatest_gap = int(intervals.max() / 60000.0)
            if greatest_gap > self.gap_tolerance_ohlcvs_minutes:
                logging.warning(
                    f"[{self.exchange}] Gaps detected in {coin} OHLCV data. Greatest gap: {greatest_gap} minutes. Returning empty DataFrame."
                )
                return pd.DataFrame(columns=df.columns)
            else:
                df = fill_gaps_in_ohlcvs(df)
        return df

    def copy_ohlcvs_from_old_dir(self, new_dirpath, old_dirpath, missing_days, coin):
        symbolf = self.get_symbol(coin).replace("/USDT:", "")
        files_copied = 0
        if os.path.exists(old_dirpath):
            for d0 in os.listdir(old_dirpath):
                if d0.endswith(".npy") and d0[:10] in missing_days:
                    src = os.path.join(old_dirpath, d0)
                    dst = os.path.join(new_dirpath, d0)
                    if os.path.exists(dst):
                        continue
                    try:
                        shutil.copy(src, dst)
                        files_copied += 1
                    except Exception as e:
                        logging.error(f"{self.exchange} error copying {src} -> {dst} {e}")
        if files_copied:
            logging.info(
                f"{self.exchange} copied {files_copied} files from {old_dirpath} to {new_dirpath}"
            )
            return True
        else:
            return False

    async def download_ohlcvs_binance(self, coin: str):
        # Uses Binance's data archives via binance.vision
        symbolf = self.get_symbol(coin).replace("/USDT:", "")
        dirpath = make_get_filepath(os.path.join(self.cache_filepaths["ohlcvs"], coin, ""))
        base_url = "https://data.binance.vision/data/futures/um/"
        fts = await self.get_first_timestamp(coin)
        archive_start_day = ts_to_date(int(fts))[:10] if fts and fts > 0 else None
        archive_start_month = archive_start_day[:7] if archive_start_day else None

        def filter_missing_days(days: List[str]) -> List[str]:
            if not days:
                return []
            if archive_start_day:
                return [d for d in days if d >= archive_start_day]
            return days

        missing_days = filter_missing_days(await self.get_missing_days_ohlcvs(coin))

        # Copy from old directory first
        old_dirpath = f"historical_data/ohlcvs_futures/{symbolf}/"
        if self.copy_ohlcvs_from_old_dir(dirpath, old_dirpath, missing_days, coin):
            missing_days = filter_missing_days(await self.get_missing_days_ohlcvs(coin))
            if not missing_days:
                return

        # Download monthy first (there may be gaps)
        month_now = ts_to_date(utc_ms())[:7]
        missing_months = sorted({x[:7] for x in missing_days if x[:7] != month_now})
        if archive_start_month:
            missing_months = [m for m in missing_months if m >= archive_start_month]
        month_download_success = {}
        month_tasks: list[tuple[str, asyncio.Task]] = []
        for month in missing_months:
            fpath = os.path.join(dirpath, month + ".npy")
            if not os.path.exists(fpath):
                url = f"{base_url}monthly/klines/{symbolf}/1m/{symbolf}-1m-{month}.zip"
                await self.check_rate_limit()
                month_tasks.append(
                    (
                        month,
                        asyncio.create_task(self.download_single_binance(url, fpath)),
                    )
                )
        for month, task in month_tasks:
            try:
                month_download_success[month] = bool(await task)
            except Exception:
                month_download_success[month] = False

        # Convert any monthly data to daily data
        for f in os.listdir(dirpath):
            if len(f) == 11:
                df = load_ohlcv_data(os.path.join(dirpath, f))

                df.loc[:, "datetime"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
                df.set_index("datetime", inplace=True)

                daily_groups = df.groupby(df.index.date)
                n_days_dumped = 0
                for date, daily_data in daily_groups:
                    if len(daily_data) == 1440:
                        fpath = str(date) + ".npy"
                        d_fpath = os.path.join(dirpath, fpath)
                        if not os.path.exists(d_fpath):
                            n_days_dumped += 1
                            dump_daily_ohlcv_data(
                                daily_data,
                                d_fpath,
                                date_to_ts(date.strftime("%Y-%m-%d")),
                            )
                    else:
                        logging.info(
                            f"binanceusdm incomplete daily data for {coin} {date} {len(daily_data)}"
                        )
                if n_days_dumped:
                    logging.info(f"binanceusdm dumped {n_days_dumped} daily files for {coin} {f}")
                m_fpath = os.path.join(dirpath, f)
                logging.info(f"binanceusdm removing {m_fpath}")
                os.remove(m_fpath)

        # Download missing daily
        missing_days = filter_missing_days(await self.get_missing_days_ohlcvs(coin))
        now_dt = datetime.datetime.utcnow().replace(day=1)
        prev_month_dt = (now_dt - datetime.timedelta(days=1)).replace(day=1)
        recent_months = {
            now_dt.strftime("%Y-%m"),
            prev_month_dt.strftime("%Y-%m"),
        }
        skip_daily_months = {
            month
            for month, success in month_download_success.items()
            if not success and month not in recent_months
        }
        tasks = []
        for day in missing_days:
            month = day[:7]
            if month in skip_daily_months:
                continue
            fpath = os.path.join(dirpath, day + ".npy")
            if not os.path.exists(fpath):
                url = base_url + f"daily/klines/{symbolf}/1m/{symbolf}-1m-{day}.zip"
                await self.check_rate_limit()
                tasks.append(asyncio.create_task(self.download_single_binance(url, fpath)))
        for task in tasks:
            await task

    async def download_single_binance(self, url: str, fpath: str):
        try:
            csv = await get_zip_binance(url)
            if not csv.empty:
                day = Path(fpath).stem
                dump_daily_ohlcv_data(
                    ensure_millis_df(csv),
                    fpath,
                    date_to_ts(day),
                )
                if self.verbose:
                    logging.info(f"binanceusdm Dumped data {fpath}")
                return True
            return False
        except Exception as e:
            logging.error(f"binanceusdm Failed to download {url}: {e}")
            traceback.print_exc()
            return False

    async def download_ohlcvs_bybit(self, coin: str):
        # Bybit has public data archives
        missing_days = await self.get_missing_days_ohlcvs(coin)
        if not missing_days:
            return
        symbolf = self.get_symbol(coin).replace("/USDT:", "")
        dirpath = make_get_filepath(os.path.join(self.cache_filepaths["ohlcvs"], coin, ""))

        # Copy from old directory first
        old_dirpath = f"historical_data/ohlcvs_bybit/{symbolf}/"
        if self.copy_ohlcvs_from_old_dir(dirpath, old_dirpath, missing_days, coin):
            missing_days = await self.get_missing_days_ohlcvs(coin)
            if not missing_days:
                return

        # Bybit public data: "https://public.bybit.com/trading/"
        base_url = "https://public.bybit.com/trading/"
        webpage = urlopen(f"{base_url}{symbolf}/").read().decode()

        filenames = [
            f"{symbolf}{day}.csv.gz" for day in missing_days if f"{symbolf}{day}.csv.gz" in webpage
        ]
        # Download concurrently
        async with aiohttp.ClientSession() as session:
            tasks = []
            for fn in filenames:
                url = f"{base_url}{symbolf}/{fn}"
                day = fn[-17:-7]
                await self.check_rate_limit()
                tasks.append(
                    asyncio.create_task(self.download_single_bybit(session, url, dirpath, day))
                )
            results = await asyncio.gather(*tasks, return_exceptions=True)

    async def find_first_day_bybit(self, coin: str, webpage=None) -> float:
        symbolf = self.get_symbol(coin).replace("/USDT:", "")
        # Bybit public data: "https://public.bybit.com/trading/"
        base_url = "https://public.bybit.com/trading/"
        if webpage is None:
            webpage = urlopen(f"{base_url}{symbolf}/").read().decode()
        dates = [date for x in webpage.split(".csv.gz") if is_valid_date((date := x[-10:]))]
        first_ts = date_to_ts(sorted(dates)[0])
        self.dump_first_timestamp(coin, first_ts)
        return first_ts

    async def download_single_bybit(self, session, url: str, dirpath: str, day: str) -> pd.DataFrame:
        try:
            resp = await fetch_url(session, url)
            with gzip.open(BytesIO(resp)) as f:
                raw = pd.read_csv(f)
            # Convert trades to OHLCV
            interval = 60000
            groups = raw.groupby((raw.timestamp * 1000) // interval * interval)
            ohlcvs = pd.DataFrame(
                {
                    "open": groups.price.first(),
                    "high": groups.price.max(),
                    "low": groups.price.min(),
                    "close": groups.price.last(),
                    "volume": groups["size"].sum(),
                }
            )
            ohlcvs["timestamp"] = ohlcvs.index
            fpath = os.path.join(dirpath, day + ".npy")
            dump_daily_ohlcv_data(
                ensure_millis_df(ohlcvs[["timestamp", "open", "high", "low", "close", "volume"]]),
                fpath,
                date_to_ts(day),
            )
            if self.verbose:
                logging.info(f"bybit Dumped {fpath}")
        except Exception as e:
            logging.error(f"bybit error {url}: {e}")
            traceback.print_exc()
            return pd.DataFrame()

    async def download_ohlcvs_bitget(self, coin: str):
        # Bitget has public data archives
        fts = await self.find_first_day_bitget(coin)
        if fts == 0.0:
            return
        first_day = ts_to_date(fts)
        missing_days = await self.get_missing_days_ohlcvs(coin)
        if not missing_days:
            return
        symbolf = self.get_symbol(coin).replace("/USDT:", "")
        if not symbolf:
            return
        dirpath = make_get_filepath(os.path.join(self.cache_filepaths["ohlcvs"], coin, ""))
        base_url = "https://img.bitgetimg.com/online/kline/"
        # Download daily
        tasks = []
        for day in sorted(missing_days):
            fpath = day + ".npy"
            await self.check_rate_limit()
            tasks.append(
                asyncio.create_task(
                    self.download_single_bitget(
                        base_url, symbolf, day, os.path.join(dirpath, day + ".npy")
                    )
                )
            )
        for task in tasks:
            try:
                await task
            except Exception as e:
                logging.error(f"bitget Error with downloader for {coin} {e}")
                # traceback.print_exc()

    def get_url_bitget(self, base_url, symbolf, day):
        if day <= "2024-04-18":
            return f"{base_url}{symbolf}/{symbolf}_UMCBL_1min_{day.replace('-', '')}.zip"
        else:
            return f"{base_url}{symbolf}/UMCBL/{day.replace('-', '')}.zip"

    async def download_single_bitget(self, base_url, symbolf, day, fpath):
        url = self.get_url_bitget(base_url, symbolf, day)
        res = await get_zip_bitget(url)
        dump_daily_ohlcv_data(ensure_millis_df(res), fpath, date_to_ts(day))
        if self.verbose:
            logging.info(f"bitget Dumped daily data {fpath}")

    async def find_first_day_bitget(self, coin: str, start_year=2020) -> float:
        """Find first day where data is available for a given symbol"""
        if fts := self.load_first_timestamp(coin):
            return fts
        if not self.markets:
            await self.load_markets()
        symbol = self.get_symbol(coin).replace("/USDT:", "")
        if not symbol:
            fts = 0.0
            self.dump_first_timestamp(coin, fts)
            return fts
        base_url = "https://img.bitgetimg.com/online/kline/"
        start = datetime.datetime(start_year, 1, 1)
        end = datetime.datetime.now()
        earliest = None

        while start <= end:
            mid = start + (end - start) // 2
            date_str = mid.strftime("%Y%m%d")
            url = self.get_url_bitget(base_url, symbol, date_str)

            try:
                await self.check_rate_limit()
                async with aiohttp.ClientSession() as session:
                    async with session.head(url) as response:
                        if self.verbose:
                            logging.info(
                                f"bitget, searching for first day of data for {symbol} {str(mid)[:10]}"
                            )
                        if response.status == 200:
                            earliest = mid
                            end = mid - datetime.timedelta(days=1)
                        else:
                            start = mid + datetime.timedelta(days=1)
            except Exception as e:
                start = mid + datetime.timedelta(days=1)

        if earliest:
            # Verify by checking the previous day
            prev_day = earliest - datetime.timedelta(days=1)
            prev_url = self.get_url_bitget(base_url, symbol, prev_day.strftime("%Y%m%d"))
            try:
                await self.check_rate_limit()
                async with aiohttp.ClientSession() as session:
                    async with session.head(prev_url) as response:
                        if response.status == 200:
                            earliest = prev_day
            except Exception:
                pass
            if self.verbose:
                logging.info(f"Bitget, found first day for {symbol}: {earliest.strftime('%Y-%m-%d')}")
            # dump cache
            fts = date_to_ts(earliest.strftime("%Y-%m-%d"))
            self.dump_first_timestamp(coin, fts)
            return fts
        return None

    async def download_ohlcvs_kucoin(self, coin: str):
        # KuCoin has public data archives for futures
        missing_days = await self.get_missing_days_ohlcvs(coin)
        if not missing_days:
            return
        symbolf = self.get_symbol(coin).replace("/USDT:", "") + "M"
        dirpath = make_get_filepath(os.path.join(self.cache_filepaths["ohlcvs"], coin, ""))
        tasks = []
        for day in sorted(missing_days):
            fpath = os.path.join(dirpath, day + ".npy")
            await self.check_rate_limit()
            tasks.append(asyncio.create_task(self.download_single_kucoin(symbolf, day, fpath)))
        for task in tasks:
            try:
                await task
            except Exception as e:
                logging.error(f"kucoin Error with downloader for {coin} {e}")

    async def download_single_kucoin(self, symbolf: str, day: str, fpath: str):
        url = f"https://historical-data.kucoin.com/data/futures/daily/klines/{symbolf}/1m/{symbolf}-1m-{day}.zip"
        try:
            zips = await fetch_zips(url)
            if not zips:
                if self.verbose:
                    logging.info(f"kucoin No data at {url}")
                return
            dfs = []
            for z in zips:
                df = pd.read_csv(z)
                df.columns = [c.strip().lower() for c in df.columns]
                if "time" in df.columns:
                    df = df.rename(columns={"time": "timestamp"})
                required = ["timestamp", "open", "high", "low", "close", "volume"]
                missing = [c for c in required if c not in df.columns]
                if missing:
                    raise Exception(f"kucoin missing columns {missing} in {url}")
                dfs.append(df[required])
            dfc = pd.concat(dfs, ignore_index=True)
            # Cast and sort
            for c in ["timestamp", "open", "high", "low", "close", "volume"]:
                dfc[c] = pd.to_numeric(dfc[c], errors="coerce")
            dfc = dfc.dropna(subset=["timestamp"]).sort_values("timestamp").reset_index(drop=True)
            # Normalize timestamp to ms
            dfc = ensure_millis_df(dfc)
            # Clip to day and fill minute gaps
            start_ts_day = date_to_ts(day)
            end_ts_day = start_ts_day + 24 * 60 * 60 * 1000
            dfc = dfc[(dfc["timestamp"] >= start_ts_day) & (dfc["timestamp"] < end_ts_day)]
            if dfc.empty:
                if self.verbose:
                    logging.info(f"kucoin Empty filtered dataframe for {symbolf} {day}")
                return
            # Deduplicate by timestamp
            dfc = dfc.drop_duplicates(subset=["timestamp"], keep="last")
            # Reindex to full 1m grid and fill
            expected_ts = np.arange(start_ts_day, end_ts_day, 60000)
            dfc = dfc.set_index("timestamp").reindex(expected_ts)
            dfc["close"] = dfc["close"].ffill()
            for col in ["open", "high", "low"]:
                dfc[col] = dfc[col].fillna(dfc["close"])
            dfc["volume"] = dfc["volume"].fillna(0.0)
            dfc = dfc.reset_index().rename(columns={"index": "timestamp"})
            if len(dfc) == 1440:
                dump_daily_ohlcv_data(ensure_millis_df(dfc), fpath, start_ts_day)
                if self.verbose:
                    logging.info(f"kucoin Dumped daily data {fpath}")
            else:
                if self.verbose:
                    logging.info(f"kucoin incomplete daily data for {symbolf} {day}: {len(dfc)} rows")
        except Exception as e:
            logging.error(f"kucoin Failed to download {url}: {e}")
            traceback.print_exc()

    async def find_first_day_kucoin(self, coin: str, start_year=2019) -> float:
        """Find first day where data is available for a given symbol on KuCoin futures"""
        if fts := self.load_first_timestamp(coin):
            return fts
        if not self.markets:
            await self.load_markets()
        symbolf = self.get_symbol(coin).replace("/USDT:", "") + "M"
        base_url = "https://historical-data.kucoin.com/data/futures/daily/klines/"
        start = datetime.datetime(start_year, 1, 1)
        end = datetime.datetime.utcnow()
        earliest = None

        while start <= end:
            mid = start + (end - start) // 2
            day = mid.strftime("%Y-%m-%d")
            url = f"{base_url}{symbolf}/1m/{symbolf}-1m-{day}.zip"
            try:
                await self.check_rate_limit()
                async with aiohttp.ClientSession() as session:
                    async with session.head(url) as response:
                        if self.verbose:
                            logging.info(
                                f"kucoin, searching for first day of data for {symbolf} {day}"
                            )
                        if response.status == 200:
                            earliest = mid
                            end = mid - datetime.timedelta(days=1)
                        else:
                            start = mid + datetime.timedelta(days=1)
            except Exception:
                start = mid + datetime.timedelta(days=1)

        if earliest:
            prev_day = earliest - datetime.timedelta(days=1)
            prev_day_str = prev_day.strftime("%Y-%m-%d")
            prev_url = f"{base_url}{symbolf}/1m/{symbolf}-1m-{prev_day_str}.zip"
            try:
                await self.check_rate_limit()
                async with aiohttp.ClientSession() as session:
                    async with session.head(prev_url) as response:
                        if response.status == 200:
                            earliest = prev_day
            except Exception:
                pass
            fts = date_to_ts(earliest.strftime("%Y-%m-%d"))
            self.dump_first_timestamp(coin, fts)
            if self.verbose:
                logging.info(
                    f"KuCoin, found first day for {symbolf}: {earliest.strftime('%Y-%m-%d')}"
                )
            return fts
        fts = 0.0
        self.dump_first_timestamp(coin, fts)
        return fts

    async def download_ohlcvs_gateio(self, coin: str):
        # GateIO doesn't have public data archives, but has ohlcvs via REST API
        missing_days = await self.get_missing_days_ohlcvs(coin)
        if not missing_days:
            return
        if self.cc is None:
            self.load_cc()
        dirpath = make_get_filepath(os.path.join(self.cache_filepaths["ohlcvs"], coin, ""))
        symbol = self.get_symbol(coin)

        # Instead of downloading in small chunks, do a single fetch for each day
        # This avoids multiple .fetch_ohlcv() calls that might exceed rate limits.
        tasks = []
        for day in missing_days:
            await self.check_rate_limit()
            tasks.append(asyncio.create_task(self.fetch_and_save_day_gateio(symbol, day, dirpath)))
        for task in tasks:
            await task

    async def fetch_and_save_day_gateio(self, symbol: str, day: str, dirpath: str):
        """
        Fetches one full day of OHLCV data from GateIO with a single call,
        then dumps it to disk. Uses self.check_rate_limit() to avoid exceeding
        the per-minute request cap.
        """
        fpath = os.path.join(dirpath, f"{day}.npy")
        start_ts_day = date_to_ts(day)  # 00:00:00 UTC of 'day'
        end_ts_day = start_ts_day + 24 * 60 * 60 * 1000  # next 24 hours
        interval = "1m"

        # GateIO typically allows up to 1440+ limit for 1m timeframe in one call
        limit = 1500
        ohlcvs = await self.cc.fetch_ohlcv(
            symbol, timeframe=interval, since=start_ts_day, limit=limit
        )
        if not ohlcvs:
            # No data returned; skip
            if self.verbose:
                logging.info(f"No data returned for GateIO {symbol} {day}")
            return

        # Convert to DataFrame
        df_day = pd.DataFrame(ohlcvs, columns=["timestamp", "open", "high", "low", "close", "volume"])
        # Filter exactly for the given day (start_ts_day <= ts < end_ts_day)
        df_day = df_day[
            (df_day.timestamp >= start_ts_day) & (df_day.timestamp < end_ts_day)
        ].reset_index(drop=True)

        # Convert volume from quote to base volume if needed
        # (Gate.io's swap markets typically return quote-volume in "volume")
        # Adjust if your usage needs base volume. E.g.:
        df_day["volume"] = df_day["volume"] / df_day["close"]

        # Dump final day data only if is a full day
        if len(df_day) == 1440:
            dump_daily_ohlcv_data(ensure_millis_df(df_day), fpath, start_ts_day)
            if self.verbose:
                logging.info(f"gateio Dumped daily OHLCV data for {symbol} to {fpath}")

    def load_first_timestamp(self, coin):
        if os.path.exists(self.cache_filepaths["first_timestamps"]):
            try:
                ftss = json.load(open(self.cache_filepaths["first_timestamps"]))
                if coin in ftss:
                    return ftss[coin]
            except Exception as e:
                logging.error(f"Error loading {self.cache_filepaths['first_timestamps']} {e}")

    def dump_first_timestamp(self, coin, fts):
        try:
            fpath = self.cache_filepaths["first_timestamps"]
            if os.path.exists(fpath):
                try:
                    ftss = json.load(open(fpath))
                except Exception as e0:
                    logging.error(f"Error loading {fpath} {e0}")
                    ftss = {}
            else:
                make_get_filepath(fpath)
                ftss = {}
            ftss[coin] = fts
            json.dump(ftss, open(fpath, "w"), indent=True, sort_keys=True)
            if self.verbose:
                logging.info(f"{self.exchange} Dumped {fpath}")
        except Exception as e:
            logging.error(f"Error with {get_function_name()} {e}")


async def prepare_hlcvs(config: dict, exchange: str):
    approved = require_live_value(config, "approved_coins")
    coins = sorted(
        set(symbol_to_coin(c) for c in approved["long"])
        | set(symbol_to_coin(c) for c in approved["short"])
    )
    exchange = normalize_exchange_name(exchange)
    requested_start_date = require_config_value(config, "backtest.start_date")
    requested_start_ts = int(date_to_ts(requested_start_date))
    end_date = format_end_date(require_config_value(config, "backtest.end_date"))
    end_ts = int(date_to_ts(end_date))

    warmup_minutes = compute_backtest_warmup_minutes(config)
    minute_ms = 60_000
    warmup_ms = warmup_minutes * minute_ms
    effective_start_ts = max(0, requested_start_ts - warmup_ms)
    effective_start_ts = (effective_start_ts // minute_ms) * minute_ms
    effective_start_date = ts_to_date(effective_start_ts)

    if warmup_minutes > 0:
        logging.info(
            f"{exchange} applying warmup: {warmup_minutes} minutes -> fetch start {effective_start_date}, "
            f"requested start {requested_start_date}"
        )

    # Initialize OHLCVManager for the exchange using the extended warmup range
    om = OHLCVManager(
        exchange,
        effective_start_date,
        end_date,
        gap_tolerance_ohlcvs_minutes=require_config_value(
            config, "backtest.gap_tolerance_ohlcvs_minutes"
        ),
    )

    try:
        # Prepare HLCV data
        mss, timestamps, hlcvs = await prepare_hlcvs_internal(
            config,
            coins,
            exchange,
            effective_start_ts,
            requested_start_ts,
            end_ts,
            om,
        )

        om.update_date_range(timestamps[0], timestamps[-1])
        btc_df = await om.get_ohlcvs("BTC")
        if btc_df.empty:
            raise ValueError(f"Failed to fetch BTC/USD prices from {exchange}")

        # Ensure BTC/USD timestamps align with HLCV timestamps
        btc_df = btc_df.set_index("timestamp").reindex(timestamps, method="ffill").reset_index()
        btc_usd_prices = btc_df["close"].values  # Extract 1D array of closing prices

        warmup_provided = max(0, int(max(0, requested_start_ts - int(timestamps[0])) // minute_ms))
        mss["__meta__"] = {
            "requested_start_ts": int(requested_start_ts),
            "requested_start_date": ts_to_date(requested_start_ts),
            "effective_start_ts": int(timestamps[0]),
            "effective_start_date": ts_to_date(int(timestamps[0])),
            "warmup_minutes_requested": int(warmup_minutes),
            "warmup_minutes_provided": int(warmup_provided),
        }

        return mss, timestamps, hlcvs, btc_usd_prices
    finally:
        if om.cc:
            await om.cc.close()


async def prepare_hlcvs_internal(
    config,
    coins,
    exchange,
    effective_start_ts,
    requested_start_ts,
    end_ts,
    om,
):
    minimum_coin_age_days = float(require_live_value(config, "minimum_coin_age_days"))
    interval_ms = 60000

    first_timestamps_unified = await get_first_timestamps_unified(coins)
    per_coin_warmups = compute_per_coin_warmup_minutes(config)
    default_warm = int(per_coin_warmups.get("__default__", 0))

    # Create cache directory if it doesn't exist
    cache_dir = Path(f"./caches/hlcvs_data/{uuid4().hex[:16]}")
    cache_dir.mkdir(parents=True, exist_ok=True)

    # First pass: Download data and store metadata
    coin_metadata = {}

    valid_coins = {}
    global_start_time = float("inf")
    global_end_time = float("-inf")
    await om.load_markets()
    min_coin_age_ms = 1000 * 60 * 60 * 24 * minimum_coin_age_days

    # First pass: Download and save data, collect metadata
    for coin in coins:
        adjusted_start_ts = effective_start_ts
        if not om.has_coin(coin):
            logging.info(f"{exchange} coin {coin} missing, skipping")
            continue
        if coin not in first_timestamps_unified:
            logging.info(f"coin {coin} missing from first_timestamps_unified, skipping")
            continue
        if minimum_coin_age_days > 0.0:
            try:
                first_ts = await om.get_first_timestamp(coin)
            except Exception as e:
                logging.error(f"error with get_first_timestamp for {coin} {e}. Skipping")
                traceback.print_exc()
                continue
            if first_ts >= end_ts:
                logging.info(
                    f"{exchange} Coin {coin} too young, start date {ts_to_date(first_ts)}. Skipping"
                )
                continue
            coin_age_days = int(
                round(utc_ms() - first_timestamps_unified[coin]) / (1000 * 60 * 60 * 24)
            )
            if coin_age_days < minimum_coin_age_days:
                logging.info(
                    f"{exchange} Coin {coin}: Not traded due to min_coin_age {int(minimum_coin_age_days)} days. "
                    f"{coin} is {coin_age_days} days old. Skipping"
                )
                continue
            new_adjusted_start_ts = max(first_timestamps_unified[coin] + min_coin_age_ms, first_ts)
            if new_adjusted_start_ts > adjusted_start_ts:
                logging.info(
                    f"{exchange} Coin {coin}: Adjusting start date from {ts_to_date(adjusted_start_ts)} "
                    f"to {ts_to_date(new_adjusted_start_ts)}"
                )
                adjusted_start_ts = new_adjusted_start_ts
        try:
            om.update_date_range(adjusted_start_ts)
            df = await om.get_ohlcvs(coin)
            data = df[["timestamp", "high", "low", "close", "volume"]].values
        except Exception as e:
            logging.error(f"error with get_ohlcvs for {coin} {e}. Skipping")
            traceback.print_exc()
            continue
        if len(data) == 0:
            continue

        assert (np.diff(data[:, 0]) == interval_ms).all(), f"gaps in hlcv data {coin}"

        # Save data to disk
        file_path = cache_dir / f"{coin}.npy"
        dump_ohlcv_data(data, file_path)

        # Update metadata
        coin_metadata[coin] = {
            "start_time": int(data[0, 0]),
            "end_time": int(data[-1, 0]),
            "length": len(data),
        }

        valid_coins[coin] = file_path
        global_start_time = min(global_start_time, data[0, 0])
        global_end_time = max(global_end_time, data[-1, 0])

    if not valid_coins:
        raise ValueError("No valid coins found with data")

    # Calculate dimensions for the unified array
    n_timesteps = int((global_end_time - global_start_time) / interval_ms) + 1
    n_coins = len(valid_coins)

    # Create the timestamp array
    timestamps = np.arange(global_start_time, global_end_time + interval_ms, interval_ms)

    # Pre-allocate the unified array
    unified_array = np.full((n_timesteps, n_coins, 4), np.nan, dtype=np.float64)
    valid_index_ranges = {}

    # Second pass: Load data from disk and populate the unified array
    logging.info(
        f"{exchange} Unifying data for {len(valid_coins)} coin{'s' if len(valid_coins) > 1 else ''} into single numpy array..."
    )
    for i, coin in enumerate(tqdm(valid_coins, desc="Processing coins", unit="coin")):
        file_path = valid_coins[coin]
        ohlcv = np.load(file_path)

        # Calculate indices
        start_idx = int((ohlcv[0, 0] - global_start_time) / interval_ms)
        end_idx = start_idx + len(ohlcv)

        # Extract and process data
        coin_data = ohlcv[:, 1:]

        # Place the data in the unified array
        unified_array[start_idx:end_idx, i, :] = coin_data
        first_idx = int(start_idx)
        last_idx = int(end_idx - 1)
        warm_minutes = int(per_coin_warmups.get(coin, default_warm))
        trade_start_idx = first_idx + warm_minutes
        if trade_start_idx > last_idx:
            trade_start_idx = last_idx
        valid_index_ranges[coin] = (first_idx, last_idx)

        # Clean up temporary file
        os.remove(file_path)

    # Clean up cache directory if empty
    try:
        os.rmdir(cache_dir)
    except OSError:
        pass
    mss = {}
    for coin in sorted(valid_coins):
        meta = om.get_market_specific_settings(coin)
        first_idx, last_idx = valid_index_ranges.get(
            coin, (unified_array.shape[0], unified_array.shape[0])
        )
        meta["first_valid_index"] = first_idx
        meta["last_valid_index"] = last_idx
        warm_minutes = int(per_coin_warmups.get(coin, default_warm))
        meta["warmup_minutes"] = warm_minutes
        trade_start_idx = first_idx + warm_minutes
        if trade_start_idx > last_idx:
            trade_start_idx = last_idx
        meta["trade_start_index"] = trade_start_idx
        mss[coin] = meta
    return mss, timestamps, unified_array


async def prepare_hlcvs_combined(config, forced_sources=None):
    backtest_exchanges = require_config_value(config, "backtest.exchanges")
    exchanges_to_consider = [normalize_exchange_name(e) for e in backtest_exchanges]
    forced_sources = forced_sources or {}
    normalized_forced_sources = {
        str(coin): normalize_exchange_name(exchange)
        for coin, exchange in forced_sources.items()
        if exchange
    }

    requested_start_date = require_config_value(config, "backtest.start_date")
    requested_start_ts = int(date_to_ts(requested_start_date))
    end_date = format_end_date(require_config_value(config, "backtest.end_date"))
    end_ts = int(date_to_ts(end_date))

    warmup_minutes = compute_backtest_warmup_minutes(config)
    minute_ms = 60_000
    warmup_ms = warmup_minutes * minute_ms
    effective_start_ts = max(0, requested_start_ts - warmup_ms)
    effective_start_ts = (effective_start_ts // minute_ms) * minute_ms
    effective_start_date = ts_to_date(effective_start_ts)

    if warmup_minutes > 0:
        logging.info(
            f"combined applying warmup: {warmup_minutes} minutes -> fetch start {effective_start_date}, "
            f"requested start {requested_start_date}"
        )

    om_dict = {}
    for ex in exchanges_to_consider:
        om_dict[ex] = OHLCVManager(
            ex,
            effective_start_date,
            end_date,
            gap_tolerance_ohlcvs_minutes=require_config_value(
                config, "backtest.gap_tolerance_ohlcvs_minutes"
            ),
        )
    extra_forced = set(normalized_forced_sources.values()) - set(exchanges_to_consider)
    for ex in extra_forced:
        om_dict[ex] = OHLCVManager(
            ex,
            effective_start_date,
            end_date,
            gap_tolerance_ohlcvs_minutes=require_config_value(
                config, "backtest.gap_tolerance_ohlcvs_minutes"
            ),
        )
    btc_om = None

    try:
        mss, timestamps, unified_array = await _prepare_hlcvs_combined_impl(
            config,
            om_dict,
            effective_start_ts,
            requested_start_ts,
            end_ts,
            normalized_forced_sources,
        )

        # Always fetch BTC/USD prices
        btc_exchange = exchanges_to_consider[0] if len(exchanges_to_consider) == 1 else "binanceusdm"
        btc_om = OHLCVManager(
            btc_exchange,
            effective_start_date,
            end_date,
            gap_tolerance_ohlcvs_minutes=require_config_value(
                config, "backtest.gap_tolerance_ohlcvs_minutes"
            ),
        )
        btc_df = await btc_om.get_ohlcvs("BTC")
        if btc_df.empty:
            raise ValueError(f"Failed to fetch BTC/USD prices from {btc_exchange}")

        # Align BTC/USD timestamps with unified timestamps
        btc_df = btc_df.set_index("timestamp").reindex(timestamps, method="ffill").reset_index()
        btc_usd_prices = btc_df["close"].values

        warmup_provided = max(0, int(max(0, requested_start_ts - int(timestamps[0])) // minute_ms))
        mss["__meta__"] = {
            "requested_start_ts": int(requested_start_ts),
            "requested_start_date": ts_to_date(requested_start_ts),
            "effective_start_ts": int(timestamps[0]),
            "effective_start_date": ts_to_date(int(timestamps[0])),
            "warmup_minutes_requested": int(warmup_minutes),
            "warmup_minutes_provided": int(warmup_provided),
        }

        return mss, timestamps, unified_array, btc_usd_prices
    finally:
        for om in om_dict.values():
            if om.cc:
                await om.cc.close()
        if btc_om and btc_om.cc:
            await btc_om.cc.close()


async def _prepare_hlcvs_combined_impl(
    config,
    om_dict,
    base_start_ts,
    _requested_start_ts,
    end_ts,
    forced_sources,
):
    """
    Amalgamates data from different exchanges for each coin in config, then unifies them into a single
    numpy array with shape (n_timestamps, n_coins, 4). The final data per coin is chosen using:

        1) Filter out exchanges that don't fully cover [start_date, end_date]
        2) Among the remaining, pick the exchange with the fewest data gaps
        3) If still tied, pick the exchange with the highest total volume

    Returns:
        mss: dict of coin -> market_specific_settings from the chosen exchange
        timestamps: 1D numpy array of all timestamps (1min granularity) covering the entire combined range
        unified_array: 3D numpy array with shape (len(timestamps), n_coins, 4),
                       where the last dimension is [high, low, close, volume].
                       Price fields are forward-filled; volume is 0-filled for missing data.
    """
    # ---------------------------------------------------------------
    # 0) Define or load relevant info from config
    # ---------------------------------------------------------------
    # Pull out all coins from config:
    approved = require_live_value(config, "approved_coins")
    coins = sorted(
        set(symbol_to_coin(c) for c in approved["long"])
        | set(symbol_to_coin(c) for c in approved["short"])
    )

    # If your config includes a list of exchanges, grab it; else pick a default set:
    exchanges_to_consider = [
        "binanceusdm" if e == "binance" else e
        for e in require_config_value(config, "backtest.exchanges")
    ]

    # Minimum coin age handling (same approach as prepare_hlcvs)
    min_coin_age_days = float(require_live_value(config, "minimum_coin_age_days"))
    min_coin_age_ms = int(min_coin_age_days * 24 * 60 * 60 * 1000)

    # First timestamps from your pre-cached or dynamically fetched data
    # (some procedures rely on e.g. get_first_timestamps_unified())
    first_timestamps_unified = await get_first_timestamps_unified(coins)

    for ex in exchanges_to_consider:
        await om_dict[ex].load_markets()

    # ---------------------------------------------------------------
    # 2) For each coin, gather 1m data from all exchanges, filter/choose best
    # ---------------------------------------------------------------
    chosen_data_per_coin = {}  # coin -> pd.DataFrame of final chosen data
    chosen_mss_per_coin = {}  # coin -> market_specific_settings from chosen exchange

    for coin in coins:
        # If the global "first_timestamps_unified" says we have no data for coin, skip immediately
        coin_fts = first_timestamps_unified.get(coin, 0.0)
        if coin_fts == 0.0:
            logging.info(f"Skipping coin {coin}, no first timestamp recorded.")
            continue

        # Check if coin is "too young": first_ts + min_coin_age >= end_ts
        coin_age_days = int(round(utc_ms() - coin_fts) / (1000 * 60 * 60 * 24))
        if coin_age_days < min_coin_age_days:
            logging.info(
                f"Skipping coin {coin}: it does not satisfy the minimum_coin_age_days = {min_coin_age_days}. "
                f"{coin} is {coin_age_days} days old."
            )
            continue

        # The earliest time we can start from, given coin's first trade time plus coin age
        effective_start_ts = max(base_start_ts, coin_fts + min_coin_age_ms)
        if effective_start_ts >= end_ts:
            # No coverage needed or possible
            continue

        forced_exchange = forced_sources.get(coin)
        candidate_exchanges = [forced_exchange] if forced_exchange else exchanges_to_consider
        for ex in candidate_exchanges:
            if ex not in om_dict:
                raise ValueError(f"Unknown exchange '{ex}' requested for coin {coin}")

        tasks = []
        for ex in candidate_exchanges:
            tasks.append(
                asyncio.create_task(
                    fetch_data_for_coin_and_exchange(
                        coin, ex, om_dict[ex], effective_start_ts, end_ts
                    )
                )
            )
        # Gather results concurrently
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Filter out None/Exceptions, build exchange_candidates
        exchange_candidates = []
        for r in results:
            if r is None or isinstance(r, Exception):
                continue
            ex, df, coverage_count, gap_count, total_volume = r
            exchange_candidates.append((ex, df, coverage_count, gap_count, total_volume))

        if not exchange_candidates:
            if forced_exchange:
                raise ValueError(
                    f"No exchange data found for coin {coin} on forced exchange {forced_exchange}."
                )
            logging.info(f"No exchange data found at all for coin {coin}. Skipping.")
            continue

        if forced_exchange:
            chosen = [c for c in exchange_candidates if c[0] == forced_exchange]
            if not chosen:
                raise ValueError(
                    f"Forced exchange {forced_exchange} returned no usable data for coin {coin}."
                )
            best_exchange, best_df, best_cov, best_gaps, best_vol = chosen[0]
        elif len(exchange_candidates) == 1:
            best_exchange, best_df, best_cov, best_gaps, best_vol = exchange_candidates[0]
        else:
            exchange_candidates.sort(key=lambda x: (x[2], -x[3], x[4]), reverse=True)
            best_exchange, best_df, best_cov, best_gaps, best_vol = exchange_candidates[0]
        logging.info(f"{coin} exchange preference: {[x[0] for x in exchange_candidates]}")

        chosen_data_per_coin[coin] = best_df
        chosen_mss_per_coin[coin] = om_dict[best_exchange].get_market_specific_settings(coin)
        chosen_mss_per_coin[coin]["exchange"] = best_exchange
    # ---------------------------------------------------------------
    # If no coins survived, raise error
    # ---------------------------------------------------------------
    if not chosen_data_per_coin:
        raise ValueError("No coin data found on any exchange for the requested date range.")

    # ---------------------------------------------------------------
    # 6) Unify across coins into a single (n_timestamps, n_coins, 4) array
    #    We'll unify on 1m timestamps from the earliest to latest across all chosen coins
    # ---------------------------------------------------------------
    global_start_time = min(df.timestamp.iloc[0] for df in chosen_data_per_coin.values())
    global_end_time = max(df.timestamp.iloc[-1] for df in chosen_data_per_coin.values())

    timestamps = np.arange(global_start_time, global_end_time + 60000, 60000)
    n_timesteps = len(timestamps)
    valid_coins = sorted(chosen_data_per_coin.keys())
    n_coins = len(valid_coins)
    # use at most last 60 days of date range to compute volume ratios
    start_date_for_volume_ratios = ts_to_date(
        max(global_start_time, global_end_time - 1000 * 60 * 60 * 24 * 60)
    )
    end_date_for_volume_ratios = ts_to_date(global_end_time)

    exchanges_with_data = sorted(set([chosen_mss_per_coin[coin]["exchange"] for coin in valid_coins]))
    exchange_volume_ratios = await compute_exchange_volume_ratios(
        exchanges_with_data,
        valid_coins,
        start_date_for_volume_ratios,
        end_date_for_volume_ratios,
        {ex: om_dict[ex] for ex in exchanges_with_data},
    )
    exchanges_counts = defaultdict(int)
    for coin in chosen_mss_per_coin:
        exchanges_counts[chosen_mss_per_coin[coin]["exchange"]] += 1
    reference_exchange = sorted(exchanges_counts.items(), key=lambda x: x[1])[-1][0]
    exchange_volume_ratios_mapped = defaultdict(dict)
    if len(exchanges_counts) == 1:
        exchange_volume_ratios_mapped[reference_exchange][reference_exchange] = 1.0
    else:
        for ex0, ex1 in exchange_volume_ratios:
            exchange_volume_ratios_mapped[ex0][ex1] = 1 / exchange_volume_ratios[(ex0, ex1)]
            exchange_volume_ratios_mapped[ex1][ex0] = exchange_volume_ratios[(ex0, ex1)]
            exchange_volume_ratios_mapped[ex1][ex1] = 1.0
            exchange_volume_ratios_mapped[ex0][ex0] = 1.0

    pprint.pprint(dict(exchange_volume_ratios_mapped))

    # We'll store [high, low, close, volume] in the last dimension
    unified_array = np.full((n_timesteps, n_coins, 4), np.nan, dtype=np.float64)

    # For each coin i, reindex its DataFrame onto the full timestamps
    for i, coin in enumerate(valid_coins):
        df = chosen_data_per_coin[coin].copy()

        # Reindex on the global minute timestamps
        df = df.set_index("timestamp").reindex(timestamps)
        # Apply scaling factor to available volume data; missing rows remain NaN
        exchange_for_this_coin = chosen_mss_per_coin[coin]["exchange"]
        scaling_factor = exchange_volume_ratios_mapped[exchange_for_this_coin][reference_exchange]
        df["volume"] *= scaling_factor

        # Now extract columns in correct order
        coin_data = df[["high", "low", "close", "volume"]].values
        unified_array[:, i, :] = coin_data
        start_idx = int((chosen_data_per_coin[coin].timestamp.iloc[0] - global_start_time) / 60000)
        end_idx = start_idx + len(chosen_data_per_coin[coin]) - 1
        chosen_mss_per_coin[coin]["first_valid_index"] = start_idx
        chosen_mss_per_coin[coin]["last_valid_index"] = end_idx

    # ---------------------------------------------------------------
    # 7) Cleanup: close all ccxt clients if needed
    # ---------------------------------------------------------------
    for om in om_dict.values():
        if om.cc:
            await om.cc.close()

    # ---------------------------------------------------------------
    # Return final:
    #   - chosen_mss_per_coin: dict coin-> market settings from the chosen exchange
    #   - timestamps: 1D array of all unified timestamps
    #   - unified_array: shape (n_timestamps, n_coins, 4) => [H, L, C, V]
    # ---------------------------------------------------------------
    return chosen_mss_per_coin, timestamps, unified_array


async def fetch_data_for_coin_and_exchange(
    coin: str, ex: str, om: OHLCVManager, effective_start_ts: int, end_ts: int
):
    """
    Fetch data for (coin, ex) between [effective_start_ts, end_ts].
    Returns (ex, df, coverage_count, gap_count, total_volume), where:
        - ex:                the exchange name
        - df:                the OHLCV dataframe
        - coverage_count:    total number of rows in df
        - gap_count:         sum of missing minutes across all gaps
        - total_volume:      sum of 'volume' column (within the timeframe)
    """

    # Check if coin is listed on this exchange
    if not om.has_coin(coin):
        return None

    # Adjust the manager's date range to [effective_start_ts, end_ts]
    om.update_date_range(effective_start_ts, end_ts)

    try:
        # Get the DataFrame of 1m OHLCVs
        df = await om.get_ohlcvs(coin)
    except Exception as e:
        logging.warning(f"Error retrieving {coin} from {ex}: {e}")
        traceback.print_exc()
        return None

    if df.empty:
        return None

    # Filter strictly to [effective_start_ts, end_ts]
    df = df[(df.timestamp >= effective_start_ts) & (df.timestamp <= end_ts)].reset_index(drop=True)
    if df.empty:
        return None

    # coverage_count = total number of 1m bars in df
    coverage_count = len(df)

    # ------------------------------------------------------------------
    # 1) Compute sum of all missing minutes (gap_count)
    # ------------------------------------------------------------------
    # For each consecutive pair, the difference in timestamps should be 60000 ms.
    # If it's bigger, we measure how many 1-minute bars are missing.
    intervals = np.diff(df["timestamp"].values)

    gap_count = sum(
        (gap // 60000) - 1  # e.g. if gap is 5 minutes => 5 - 1 = 4 missing bars
        for gap in intervals
        if gap > 60000
    )

    # total_volume = sum of volume column
    total_volume = df["volume"].sum()

    return (ex, df, coverage_count, gap_count, total_volume)


async def compute_exchange_volume_ratios(
    exchanges: List[str],
    coins: List[str],
    start_date: str,
    end_date: str,
    om_dict: Dict[str, "OHLCVManager"] = None,
) -> Dict[Tuple[str, str], float]:
    """
    Gathers daily volume for each coin on each exchange,
    filters out incomplete days (days missing from any exchange),
    and then computes pairwise volume ratios (ex0, ex1) = sumVol(ex0) / sumVol(ex1).
    Finally, it averages those ratios across all coins.

    :param exchanges: list of exchange names (e.g. ["binanceusdm", "bybit"]).
    :param coins:     list of coins (e.g. ["BTC", "ETH"]).
    :param start_date: "YYYY-MM-DD" inclusive
    :param end_date:   "YYYY-MM-DD" inclusive
    :param om_dict:   dict of {exchange_name -> OHLCVManager}, already initialized
    :return: dict {(ex0, ex1): average_ratio}, where ex0 < ex1 in alphabetical order, for example
    """
    # -------------------------------------------------------
    # 1) Build all pairs of exchanges
    # -------------------------------------------------------
    if om_dict is None:
        om_dict = {ex: OHLCVManager(ex, start_date, end_date) for ex in exchanges}
        await asyncio.gather(*[om_dict[ex].load_markets() for ex in om_dict])
    assert all([ex in om_dict for ex in exchanges])
    exchange_pairs = []
    for i, ex0 in enumerate(sorted(exchanges)):
        for ex1 in exchanges[i + 1 :]:
            # (Optional) sort them or keep them as-is
            # We'll just keep them in the (ex0, ex1) order for clarity
            exchange_pairs.append((ex0, ex1))

    # -------------------------------------------------------
    # 2) For each coin, gather data from all exchanges
    # -------------------------------------------------------
    # We'll store: all_data[coin][(ex0, ex1)] = ratio_of_volumes_for_that_coin
    all_data = {}

    for coin in coins:
        # If coin does not exist on ALL exchanges, skip
        if not all(om_dict[ex].has_coin(coin) for ex in exchanges):
            continue

        # Gather concurrent tasks => each exchange's DF for that coin
        tasks = []
        for ex in exchanges:
            om = om_dict[ex]
            om.update_date_range(start_date, end_date)
            tasks.append(
                om.get_ohlcvs(coin)
            )  # returns a DataFrame: [timestamp, open, high, low, close, volume]

        dfs = await asyncio.gather(*tasks, return_exceptions=True)
        # Filter out any exceptions or empty data
        # We'll keep them in the same order as `exchanges`
        for i, df in enumerate(dfs):
            if isinstance(df, Exception) or df is None or df.empty:
                dfs[i] = pd.DataFrame()  # mark as empty

        # If any are empty, skip coin
        if any(df.empty for df in dfs):
            continue

        # -------------------------------------------------------
        # 3) Convert each DF to daily volume.
        #    We'll produce: daily_df[day_str or day_int] = volume
        # -------------------------------------------------------
        # Approach: group by day (UTC). E.g. day_key = df.timestamp // 86400000
        # Then sum up df["volume"] for each day.

        daily_volumes = []  # daily_volumes[i] will be a dict day->volume for exchange i
        for df in dfs:
            df["day"] = df["timestamp"] // 86400000  # integer day
            grouped = df.groupby("day", as_index=False)["volume"].sum()
            # build dict {day: volume}
            daily_dict = dict(zip(grouped["day"], grouped["volume"]))
            daily_volumes.append(daily_dict)

        # Now we want to find the set of "common days" that appear in all daily_volumes
        # E.g. intersection of day keys across all exchanges
        sets_of_days = [set(dv.keys()) for dv in daily_volumes]
        common_days = set.intersection(*sets_of_days)
        if not common_days:
            continue

        # Filter out days that have no volume on some exchange
        # (Already done by intersection, but you might want to check if the volume is zero and exclude, etc.)

        # -------------------------------------------------------
        # 4) For each pair of exchanges, compute ratio over the *full* range of common days
        # -------------------------------------------------------
        # i.e. ratio = (sum of daily volumes on ex0) / (sum of daily volumes on ex1)
        coin_data = {}  # coin_data[(ex0, ex1)] = ratio for this coin
        for ex0, ex1 in exchange_pairs:
            i0 = exchanges.index(ex0)
            i1 = exchanges.index(ex1)
            sum0 = sum(daily_volumes[i0][day] for day in common_days)
            sum1 = sum(daily_volumes[i1][day] for day in common_days)
            ratio = (sum0 / sum1) if sum1 > 0 else 0.0
            coin_data[(ex0, ex1)] = ratio

        if coin_data:
            all_data[coin] = coin_data

    # -------------------------------------------------------
    # 5) Compute average ratio per (ex0, ex1) across all coins
    # -------------------------------------------------------
    # all_data is: { coin: {(ex0, ex1): ratio, (exA, exB): ratio, ...}, ... }
    # We'll gather lists of ratios per exchange pair, then compute the mean.
    averages = {}
    if not all_data:
        return averages  # empty if no coin data

    # Build a list of all pairs we actually used:
    used_pairs = set()
    for coin in all_data:
        for pair in all_data[coin]:
            used_pairs.add(pair)

    for pair in used_pairs:
        # collect all coin-specific ratios for that pair
        ratios_for_pair = []
        for coin in all_data:
            if pair in all_data[coin]:
                ratios_for_pair.append(all_data[coin][pair])
        if ratios_for_pair:
            averages[pair] = float(np.mean(ratios_for_pair))
        else:
            averages[pair] = 0.0

    return averages


async def main():
    parser = argparse.ArgumentParser(prog="downloader", description="download ohlcv data")
    parser.add_argument(
        "config_path", type=str, default=None, nargs="?", help="path to json passivbot config"
    )
    template_config = get_template_config()
    del template_config["optimize"]
    del template_config["bot"]
    template_config["live"] = {
        k: v
        for k, v in template_config["live"].items()
        if k
        in {
            "approved_coins",
            "ignored_coins",
        }
    }
    template_config["backtest"] = {
        k: v
        for k, v in template_config["backtest"].items()
        if k
        in {
            "combine_ohlcvs",
            "end_date",
            "start_date",
            "exchanges",
        }
    }
    add_arguments_recursively(parser, template_config)
    args = parser.parse_args()
    if args.config_path is None:
        logging.info(f"loading default template config configs/template.json")
        config = load_config("configs/template.json", verbose=False)
    else:
        logging.info(f"loading config {args.config_path}")
        config = load_config(args.config_path)
    update_config_with_args(config, args)
    await format_approved_ignored_coins(config, require_config_value(config, "backtest.exchanges"))
    oms = {}
    try:
        for ex in require_config_value(config, "backtest.exchanges"):
            oms[ex] = OHLCVManager(
                ex,
                require_config_value(config, "backtest.start_date"),
                require_config_value(config, "backtest.end_date"),
            )
        logging.info(f"loading markets for {require_config_value(config, 'backtest.exchanges')}")
        await asyncio.gather(*[oms[ex].load_markets() for ex in oms])
        approved = require_live_value(config, "approved_coins")
        coins = [x for y in approved.values() for x in y]
        for coin in sorted(set(coins)):
            tasks = {}
            for ex in oms:
                try:
                    tasks[ex] = asyncio.create_task(oms[ex].get_ohlcvs(coin))
                except Exception as e:
                    logging.error(f"{ex} {coin} error a with get_ohlcvs() {e}")
            for ex in tasks:
                try:
                    await tasks[ex]
                except Exception as e:
                    logging.error(f"{ex} {coin} error b with get_ohlcvs() {e}")
    finally:
        for om in oms.values():
            if om.cc:
                await om.cc.close()


if __name__ == "__main__":
    asyncio.run(main())
